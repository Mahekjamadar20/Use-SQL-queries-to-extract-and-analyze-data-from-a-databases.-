
-- 🧠 SQL for Data Analysis — E-commerce Dataset

-- 1️⃣ Create Tables
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(50),
    city VARCHAR(50),
    age INT,
    gender CHAR(1)
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    category VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    quantity INT,
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- 2️⃣ Insert Sample Data
INSERT INTO customers VALUES
(1, 'Aarav Shah', 'Mumbai', 28, 'M'),
(2, 'Meera Patel', 'Delhi', 34, 'F'),
(3, 'Riya Singh', 'Pune', 25, 'F');

INSERT INTO products VALUES
(101, 'Laptop', 'Electronics', 65000),
(102, 'Headphones', 'Accessories', 2500),
(103, 'T-Shirt', 'Fashion', 900);

INSERT INTO orders VALUES
(201, 1, 101, 1, '2024-04-15'),
(202, 2, 102, 2, '2024-04-20'),
(203, 3, 103, 3, '2024-04-22');

-- 3️⃣ Example Queries

-- a. Basic SELECT
SELECT * FROM customers ORDER BY city;

-- b. WHERE filtering
SELECT name, city, age FROM customers WHERE age > 25;

-- c. Aggregate functions
SELECT category, COUNT(*) AS total_products, AVG(price) AS avg_price
FROM products
GROUP BY category;

-- d. JOINS
SELECT c.name, p.product_name, o.quantity, (p.price * o.quantity) AS total_amount
FROM orders o
INNER JOIN customers c ON o.customer_id = c.customer_id
INNER JOIN products p ON o.product_id = p.product_id;

-- e. Subquery
SELECT name, city FROM customers
WHERE customer_id IN (
    SELECT customer_id FROM orders WHERE product_id = 101
);

-- f. HAVING
SELECT customer_id, SUM(quantity) AS total_items
FROM orders
GROUP BY customer_id
HAVING SUM(quantity) > 2;

-- g. Create View
CREATE VIEW customer_sales_summary AS
SELECT c.customer_id, c.name, SUM(p.price * o.quantity) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN products p ON o.product_id = p.product_id
GROUP BY c.customer_id, c.name;

-- h. Query View
SELECT * FROM customer_sales_summary ORDER BY total_spent DESC;

-- i. Index Optimization
CREATE INDEX idx_customer_city ON customers(city);

-- j. Top-Selling Product
SELECT p.product_name, SUM(o.quantity) AS total_sold
FROM orders o
JOIN products p ON o.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sold DESC
LIMIT 1;
